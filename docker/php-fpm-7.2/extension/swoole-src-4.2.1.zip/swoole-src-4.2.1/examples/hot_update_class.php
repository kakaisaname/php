<?php
	class HotUpdate {
		public function getData()
		{
			return "hello world~~".PHP_EOL;
		}
	}